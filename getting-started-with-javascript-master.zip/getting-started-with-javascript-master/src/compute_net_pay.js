/*

The calculateNetPayable() function should accept 3 inputs:
pricePerKilo, quantityInKilo and discountPercentage.

Calculate the net amount post discount that would be payable.

The function should return the computed value.

The function should return error message "Invalid Input Types, All Inputs Should Be of Type Number !!", 
for any non-numeric value passed to the function.

*/

module.exports = function calculateNetPayable(pricePerKilo, quantityInKilo, discountPercentage) {
  test: "mocha server/**/*.script.js --timeout 10000"
  // Provide Solution Code Here
  if(typeof pricePerKilo=='number' && typeof quantityInKilo=='number' && typeof discountPercentage=='number')
  {
    var discount = (discountPercentage/100)*pricePerKilo;
    var totdis= quantityInKilo*discount;
    return ((pricePerKilo*quantityInKilo)-totdis).toString();
  }
  else{
    return "Invalid Input Types, All Inputs Should Be of Type Number !!";}
}
