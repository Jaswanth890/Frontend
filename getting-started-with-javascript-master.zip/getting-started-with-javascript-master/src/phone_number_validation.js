/*

The checkPhoneNumber() function should accept phoneNumber as input and check if it is valid.

The provided phoneNumber is a valid phoneNumber if its value matches with any of the pattern suggested below:


+1 0999999999, 
+1 099-999-9999, 
+1 (099)-999-9999, 
  +1 (099)9999999, 
  +1 099 999 9999, 
  +1 099 999-9999, 
  +1 (099) 999-9999, 
  +1 099.999.9999
  +10999999999, 
  +1099-999-9999, 
  +1(099)-999-9999, 
  +1(099)9999999, 
  +1099 999 9999, 
  +1099 999-9999, 
  +1(099) 999-9999, 
  +1099.999.9999
  
  The function should return true if validation criteria is satisfied else should return false.
  
  Use Regular Expression to perform validation check.

*/

const isFieldBlank = (value) => {
  return value === '' || value === undefined || value === null;
}
test: "mocha server/**/*.script.js --timeout 10000"

module.exports = function checkPhoneNumber(num) {

  // Provide Solution Code Here
//   if(num.match(/([\+][0-9] [0-9]{10})/)||num.match(/([\+][0-9] [0-9]{3}[-][0-9]{3}[-][0-9]{4})/)||num.match(/([\+][0-9] [(][0-9]{3}[)][-][0-9]{3}[-][0-9]{4})/) || num.match(/([\+][0-9] ([0-9])[0-9]{7})/)||num.match(/([\+][0-9] [0-9]{3} [0-9]{3} [0-9]{4})/)|| num.match(/([\+][0-9] [0-9]{3} [0-9]{3}[-][0-9]{4})/)|| num.match(/([\+][0-9] ([0-9]{3}) [0-9]{3}[-][0-9]{4})/)||num.match(/([\+][0-9] [0-9]{3}[.][0-9]{3}[.][0-9]{4})/)||
//      num.match(/([\+][0-9][0-9]{10})/)||num.match(/([\+][0-9][0-9]{3}[-][0-9]{3}[-][0-9]{4})/)||num.match(/([\+][0-9][(][0-9]{3}[)][-][0-9]{3}[-][0-9]{4})/) || num.match(/([\+][0-9]([0-9])[0-9]{7})/)||num.match(/([\+][0-9][0-9]{3} [0-9]{3} [0-9]{4})/)|| num.match(/([\+][0-9][0-9]{3} [0-9]{3}[-][0-9]{4})/)|| num.match(/([\+][0-9]([0-9]{3}) [0-9]{3}[-][0-9]{4})/)||num.match(/([\+][0-9][0-9]{3}[.][0-9]{3}[.][0-9]{4})/))
//   {
//     return true;
//   }
// return false;
  let validRegex = /^(\+[0-9]{1,3})[ ]?\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;

    return !(!isFieldBlank(num) && !num.match(validRegex))
}
